/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.advancements.critereon;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import java.util.function.Predicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSet;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraft.world.level.storage.loot.predicates.LootItemConditions;
import org.jetbrains.annotations.Nullable;

public class ContextAwarePredicate {
    public static final ContextAwarePredicate ANY = new ContextAwarePredicate(new LootItemCondition[0]);
    private final LootItemCondition[] conditions;
    private final Predicate<LootContext> compositePredicates;

    ContextAwarePredicate(LootItemCondition[] lootItemConditions) {
        this.conditions = lootItemConditions;
        this.compositePredicates = LootItemConditions.andConditions(lootItemConditions);
    }

    public static ContextAwarePredicate create(LootItemCondition ... lootItemConditions) {
        return new ContextAwarePredicate(lootItemConditions);
    }

    @Nullable
    public static ContextAwarePredicate fromElement(String string, DeserializationContext deserializationContext, @Nullable JsonElement jsonElement, LootContextParamSet lootContextParamSet) {
        if (jsonElement != null && jsonElement.isJsonArray()) {
            LootItemCondition[] lootItemConditions = deserializationContext.deserializeConditions(jsonElement.getAsJsonArray(), deserializationContext.getAdvancementId() + "/" + string, lootContextParamSet);
            return new ContextAwarePredicate(lootItemConditions);
        }
        return null;
    }

    public boolean matches(LootContext lootContext) {
        return this.compositePredicates.test(lootContext);
    }

    public JsonElement toJson(SerializationContext serializationContext) {
        if (this.conditions.length == 0) {
            return JsonNull.INSTANCE;
        }
        return serializationContext.serializeConditions(this.conditions);
    }

    public static JsonElement toJson(ContextAwarePredicate[] contextAwarePredicates, SerializationContext serializationContext) {
        if (contextAwarePredicates.length == 0) {
            return JsonNull.INSTANCE;
        }
        JsonArray jsonArray = new JsonArray();
        for (ContextAwarePredicate contextAwarePredicate : contextAwarePredicates) {
            jsonArray.add(contextAwarePredicate.toJson(serializationContext));
        }
        return jsonArray;
    }
}

