/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.MobEffectsPredicate;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;
import org.jetbrains.annotations.Nullable;

public class EffectsChangedTrigger
extends SimpleCriterionTrigger<TriggerInstance> {
    static final ResourceLocation ID = new ResourceLocation("effects_changed");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public TriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        MobEffectsPredicate mobEffectsPredicate = MobEffectsPredicate.fromJson(jsonObject.get("effects"));
        ContextAwarePredicate contextAwarePredicate2 = EntityPredicate.fromJson(jsonObject, "source", deserializationContext);
        return new TriggerInstance(contextAwarePredicate, mobEffectsPredicate, contextAwarePredicate2);
    }

    public void trigger(ServerPlayer serverPlayer, @Nullable Entity entity) {
        LootContext lootContext = entity != null ? EntityPredicate.createContext(serverPlayer, entity) : null;
        this.trigger(serverPlayer, (T triggerInstance) -> triggerInstance.matches(serverPlayer, lootContext));
    }

    @Override
    public /* synthetic */ AbstractCriterionTriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        return this.createInstance(jsonObject, contextAwarePredicate, deserializationContext);
    }

    public static class TriggerInstance
    extends AbstractCriterionTriggerInstance {
        private final MobEffectsPredicate effects;
        private final ContextAwarePredicate source;

        public TriggerInstance(ContextAwarePredicate contextAwarePredicate, MobEffectsPredicate mobEffectsPredicate, ContextAwarePredicate contextAwarePredicate2) {
            super(ID, contextAwarePredicate);
            this.effects = mobEffectsPredicate;
            this.source = contextAwarePredicate2;
        }

        public static TriggerInstance hasEffects(MobEffectsPredicate mobEffectsPredicate) {
            return new TriggerInstance(ContextAwarePredicate.ANY, mobEffectsPredicate, ContextAwarePredicate.ANY);
        }

        public static TriggerInstance gotEffectsFrom(EntityPredicate entityPredicate) {
            return new TriggerInstance(ContextAwarePredicate.ANY, MobEffectsPredicate.ANY, EntityPredicate.wrap(entityPredicate));
        }

        public boolean matches(ServerPlayer serverPlayer, @Nullable LootContext lootContext) {
            if (!this.effects.matches(serverPlayer)) {
                return false;
            }
            return this.source == ContextAwarePredicate.ANY || lootContext != null && this.source.matches(lootContext);
        }

        @Override
        public JsonObject serializeToJson(SerializationContext serializationContext) {
            JsonObject jsonObject = super.serializeToJson(serializationContext);
            jsonObject.add("effects", this.effects.serializeToJson());
            jsonObject.add("source", this.source.toJson(serializationContext));
            return jsonObject;
        }
    }
}

