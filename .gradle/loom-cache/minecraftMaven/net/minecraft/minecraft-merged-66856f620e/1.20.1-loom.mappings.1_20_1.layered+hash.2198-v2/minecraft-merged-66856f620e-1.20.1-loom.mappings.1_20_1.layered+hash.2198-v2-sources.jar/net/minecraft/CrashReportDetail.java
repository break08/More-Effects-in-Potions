/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft;

import java.util.concurrent.Callable;

public interface CrashReportDetail<V>
extends Callable<V> {
}

