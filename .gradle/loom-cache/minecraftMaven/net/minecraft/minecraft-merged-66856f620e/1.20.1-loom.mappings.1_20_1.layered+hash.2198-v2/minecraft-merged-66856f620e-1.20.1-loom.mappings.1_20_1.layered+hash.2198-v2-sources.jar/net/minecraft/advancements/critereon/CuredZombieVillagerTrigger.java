/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.storage.loot.LootContext;

public class CuredZombieVillagerTrigger
extends SimpleCriterionTrigger<TriggerInstance> {
    static final ResourceLocation ID = new ResourceLocation("cured_zombie_villager");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public TriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        ContextAwarePredicate contextAwarePredicate2 = EntityPredicate.fromJson(jsonObject, "zombie", deserializationContext);
        ContextAwarePredicate contextAwarePredicate3 = EntityPredicate.fromJson(jsonObject, "villager", deserializationContext);
        return new TriggerInstance(contextAwarePredicate, contextAwarePredicate2, contextAwarePredicate3);
    }

    public void trigger(ServerPlayer serverPlayer, Zombie zombie, Villager villager) {
        LootContext lootContext = EntityPredicate.createContext(serverPlayer, zombie);
        LootContext lootContext2 = EntityPredicate.createContext(serverPlayer, villager);
        this.trigger(serverPlayer, triggerInstance -> triggerInstance.matches(lootContext, lootContext2));
    }

    @Override
    public /* synthetic */ AbstractCriterionTriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        return this.createInstance(jsonObject, contextAwarePredicate, deserializationContext);
    }

    public static class TriggerInstance
    extends AbstractCriterionTriggerInstance {
        private final ContextAwarePredicate zombie;
        private final ContextAwarePredicate villager;

        public TriggerInstance(ContextAwarePredicate contextAwarePredicate, ContextAwarePredicate contextAwarePredicate2, ContextAwarePredicate contextAwarePredicate3) {
            super(ID, contextAwarePredicate);
            this.zombie = contextAwarePredicate2;
            this.villager = contextAwarePredicate3;
        }

        public static TriggerInstance curedZombieVillager() {
            return new TriggerInstance(ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY);
        }

        public boolean matches(LootContext lootContext, LootContext lootContext2) {
            if (!this.zombie.matches(lootContext)) {
                return false;
            }
            return this.villager.matches(lootContext2);
        }

        @Override
        public JsonObject serializeToJson(SerializationContext serializationContext) {
            JsonObject jsonObject = super.serializeToJson(serializationContext);
            jsonObject.add("zombie", this.zombie.toJson(serializationContext));
            jsonObject.add("villager", this.villager.toJson(serializationContext));
            return jsonObject;
        }
    }
}

