/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.core;

public interface Position {
    public double x();

    public double y();

    public double z();
}

