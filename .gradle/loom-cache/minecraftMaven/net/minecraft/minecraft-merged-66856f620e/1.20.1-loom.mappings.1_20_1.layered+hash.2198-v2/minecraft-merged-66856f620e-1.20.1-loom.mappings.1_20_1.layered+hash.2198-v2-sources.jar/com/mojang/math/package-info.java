/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault
package com.mojang.math;

import com.mojang.math.FieldsAreNonnullByDefault;
import com.mojang.math.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;


