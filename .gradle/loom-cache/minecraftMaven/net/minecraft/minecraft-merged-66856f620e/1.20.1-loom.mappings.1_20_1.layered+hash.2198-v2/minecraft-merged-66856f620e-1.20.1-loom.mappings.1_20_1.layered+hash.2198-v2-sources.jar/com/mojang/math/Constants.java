/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package com.mojang.math;

public class Constants {
    public static final float PI = (float)Math.PI;
    public static final float RAD_TO_DEG = 57.295776f;
    public static final float DEG_TO_RAD = (float)Math.PI / 180;
    public static final float EPSILON = 1.0E-6f;
}

