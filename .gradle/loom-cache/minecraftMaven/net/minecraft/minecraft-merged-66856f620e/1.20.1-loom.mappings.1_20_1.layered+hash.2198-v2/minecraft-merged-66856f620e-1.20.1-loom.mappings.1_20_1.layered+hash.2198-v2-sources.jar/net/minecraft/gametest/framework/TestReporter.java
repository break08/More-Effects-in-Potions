/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.gametest.framework;

import net.minecraft.gametest.framework.GameTestInfo;

public interface TestReporter {
    public void onTestFailed(GameTestInfo var1);

    public void onTestSuccess(GameTestInfo var1);

    default public void finish() {
    }
}

