/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.commands.arguments;

import com.google.common.collect.Maps;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.Util;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;

public class SlotArgument
implements ArgumentType<Integer> {
    private static final Collection<String> EXAMPLES = Arrays.asList("container.5", "12", "weapon");
    private static final DynamicCommandExceptionType ERROR_UNKNOWN_SLOT = new DynamicCommandExceptionType(object -> Component.translatable("slot.unknown", object));
    private static final Map<String, Integer> SLOTS = Util.make(Maps.newHashMap(), hashMap -> {
        int i;
        for (i = 0; i < 54; ++i) {
            hashMap.put("container." + i, i);
        }
        for (i = 0; i < 9; ++i) {
            hashMap.put("hotbar." + i, i);
        }
        for (i = 0; i < 27; ++i) {
            hashMap.put("inventory." + i, 9 + i);
        }
        for (i = 0; i < 27; ++i) {
            hashMap.put("enderchest." + i, 200 + i);
        }
        for (i = 0; i < 8; ++i) {
            hashMap.put("villager." + i, 300 + i);
        }
        for (i = 0; i < 15; ++i) {
            hashMap.put("horse." + i, 500 + i);
        }
        hashMap.put("weapon", EquipmentSlot.MAINHAND.getIndex(98));
        hashMap.put("weapon.mainhand", EquipmentSlot.MAINHAND.getIndex(98));
        hashMap.put("weapon.offhand", EquipmentSlot.OFFHAND.getIndex(98));
        hashMap.put("armor.head", EquipmentSlot.HEAD.getIndex(100));
        hashMap.put("armor.chest", EquipmentSlot.CHEST.getIndex(100));
        hashMap.put("armor.legs", EquipmentSlot.LEGS.getIndex(100));
        hashMap.put("armor.feet", EquipmentSlot.FEET.getIndex(100));
        hashMap.put("horse.saddle", 400);
        hashMap.put("horse.armor", 401);
        hashMap.put("horse.chest", 499);
    });

    public static SlotArgument slot() {
        return new SlotArgument();
    }

    public static int getSlot(CommandContext<CommandSourceStack> commandContext, String string) {
        return commandContext.getArgument(string, Integer.class);
    }

    @Override
    public Integer parse(StringReader stringReader) throws CommandSyntaxException {
        String string = stringReader.readUnquotedString();
        if (!SLOTS.containsKey(string)) {
            throw ERROR_UNKNOWN_SLOT.create(string);
        }
        return SLOTS.get(string);
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> commandContext, SuggestionsBuilder suggestionsBuilder) {
        return SharedSuggestionProvider.suggest(SLOTS.keySet(), suggestionsBuilder);
    }

    @Override
    public Collection<String> getExamples() {
        return EXAMPLES;
    }

    @Override
    public /* synthetic */ Object parse(StringReader stringReader) throws CommandSyntaxException {
        return this.parse(stringReader);
    }
}

