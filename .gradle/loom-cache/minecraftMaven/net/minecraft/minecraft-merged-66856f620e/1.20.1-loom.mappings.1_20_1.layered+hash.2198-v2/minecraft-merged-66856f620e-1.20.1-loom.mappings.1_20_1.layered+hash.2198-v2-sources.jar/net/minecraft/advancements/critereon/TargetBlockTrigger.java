/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.MinMaxBounds;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.phys.Vec3;

public class TargetBlockTrigger
extends SimpleCriterionTrigger<TriggerInstance> {
    static final ResourceLocation ID = new ResourceLocation("target_hit");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public TriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        MinMaxBounds.Ints ints = MinMaxBounds.Ints.fromJson(jsonObject.get("signal_strength"));
        ContextAwarePredicate contextAwarePredicate2 = EntityPredicate.fromJson(jsonObject, "projectile", deserializationContext);
        return new TriggerInstance(contextAwarePredicate, ints, contextAwarePredicate2);
    }

    public void trigger(ServerPlayer serverPlayer, Entity entity, Vec3 vec3, int i) {
        LootContext lootContext = EntityPredicate.createContext(serverPlayer, entity);
        this.trigger(serverPlayer, triggerInstance -> triggerInstance.matches(lootContext, vec3, i));
    }

    @Override
    public /* synthetic */ AbstractCriterionTriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        return this.createInstance(jsonObject, contextAwarePredicate, deserializationContext);
    }

    public static class TriggerInstance
    extends AbstractCriterionTriggerInstance {
        private final MinMaxBounds.Ints signalStrength;
        private final ContextAwarePredicate projectile;

        public TriggerInstance(ContextAwarePredicate contextAwarePredicate, MinMaxBounds.Ints ints, ContextAwarePredicate contextAwarePredicate2) {
            super(ID, contextAwarePredicate);
            this.signalStrength = ints;
            this.projectile = contextAwarePredicate2;
        }

        public static TriggerInstance targetHit(MinMaxBounds.Ints ints, ContextAwarePredicate contextAwarePredicate) {
            return new TriggerInstance(ContextAwarePredicate.ANY, ints, contextAwarePredicate);
        }

        @Override
        public JsonObject serializeToJson(SerializationContext serializationContext) {
            JsonObject jsonObject = super.serializeToJson(serializationContext);
            jsonObject.add("signal_strength", this.signalStrength.serializeToJson());
            jsonObject.add("projectile", this.projectile.toJson(serializationContext));
            return jsonObject;
        }

        public boolean matches(LootContext lootContext, Vec3 vec3, int i) {
            if (!this.signalStrength.matches(i)) {
                return false;
            }
            return this.projectile.matches(lootContext);
        }
    }
}

