/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.commands.arguments;

import com.mojang.brigadier.arguments.ArgumentType;

public interface SignedArgument<T>
extends ArgumentType<T> {
}

