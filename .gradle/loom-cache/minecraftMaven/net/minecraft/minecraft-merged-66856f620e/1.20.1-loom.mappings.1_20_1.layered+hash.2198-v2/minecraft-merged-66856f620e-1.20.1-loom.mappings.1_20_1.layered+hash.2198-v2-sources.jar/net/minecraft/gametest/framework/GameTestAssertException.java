/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.gametest.framework;

public class GameTestAssertException
extends RuntimeException {
    public GameTestAssertException(String string) {
        super(string);
    }
}

