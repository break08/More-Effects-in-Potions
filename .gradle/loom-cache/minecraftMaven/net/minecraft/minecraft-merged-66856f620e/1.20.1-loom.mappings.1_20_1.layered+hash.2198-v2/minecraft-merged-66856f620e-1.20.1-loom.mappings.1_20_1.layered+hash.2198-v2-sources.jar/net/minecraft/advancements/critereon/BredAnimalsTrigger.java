/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.advancements.critereon;

import com.google.gson.JsonObject;
import net.minecraft.advancements.critereon.AbstractCriterionTriggerInstance;
import net.minecraft.advancements.critereon.ContextAwarePredicate;
import net.minecraft.advancements.critereon.DeserializationContext;
import net.minecraft.advancements.critereon.EntityPredicate;
import net.minecraft.advancements.critereon.SerializationContext;
import net.minecraft.advancements.critereon.SimpleCriterionTrigger;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.storage.loot.LootContext;
import org.jetbrains.annotations.Nullable;

public class BredAnimalsTrigger
extends SimpleCriterionTrigger<TriggerInstance> {
    static final ResourceLocation ID = new ResourceLocation("bred_animals");

    @Override
    public ResourceLocation getId() {
        return ID;
    }

    @Override
    public TriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        ContextAwarePredicate contextAwarePredicate2 = EntityPredicate.fromJson(jsonObject, "parent", deserializationContext);
        ContextAwarePredicate contextAwarePredicate3 = EntityPredicate.fromJson(jsonObject, "partner", deserializationContext);
        ContextAwarePredicate contextAwarePredicate4 = EntityPredicate.fromJson(jsonObject, "child", deserializationContext);
        return new TriggerInstance(contextAwarePredicate, contextAwarePredicate2, contextAwarePredicate3, contextAwarePredicate4);
    }

    public void trigger(ServerPlayer serverPlayer, Animal animal, Animal animal2, @Nullable AgeableMob ageableMob) {
        LootContext lootContext = EntityPredicate.createContext(serverPlayer, animal);
        LootContext lootContext2 = EntityPredicate.createContext(serverPlayer, animal2);
        LootContext lootContext3 = ageableMob != null ? EntityPredicate.createContext(serverPlayer, ageableMob) : null;
        this.trigger(serverPlayer, triggerInstance -> triggerInstance.matches(lootContext, lootContext2, lootContext3));
    }

    @Override
    public /* synthetic */ AbstractCriterionTriggerInstance createInstance(JsonObject jsonObject, ContextAwarePredicate contextAwarePredicate, DeserializationContext deserializationContext) {
        return this.createInstance(jsonObject, contextAwarePredicate, deserializationContext);
    }

    public static class TriggerInstance
    extends AbstractCriterionTriggerInstance {
        private final ContextAwarePredicate parent;
        private final ContextAwarePredicate partner;
        private final ContextAwarePredicate child;

        public TriggerInstance(ContextAwarePredicate contextAwarePredicate, ContextAwarePredicate contextAwarePredicate2, ContextAwarePredicate contextAwarePredicate3, ContextAwarePredicate contextAwarePredicate4) {
            super(ID, contextAwarePredicate);
            this.parent = contextAwarePredicate2;
            this.partner = contextAwarePredicate3;
            this.child = contextAwarePredicate4;
        }

        public static TriggerInstance bredAnimals() {
            return new TriggerInstance(ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY);
        }

        public static TriggerInstance bredAnimals(EntityPredicate.Builder builder) {
            return new TriggerInstance(ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, ContextAwarePredicate.ANY, EntityPredicate.wrap(builder.build()));
        }

        public static TriggerInstance bredAnimals(EntityPredicate entityPredicate, EntityPredicate entityPredicate2, EntityPredicate entityPredicate3) {
            return new TriggerInstance(ContextAwarePredicate.ANY, EntityPredicate.wrap(entityPredicate), EntityPredicate.wrap(entityPredicate2), EntityPredicate.wrap(entityPredicate3));
        }

        public boolean matches(LootContext lootContext, LootContext lootContext2, @Nullable LootContext lootContext3) {
            if (!(this.child == ContextAwarePredicate.ANY || lootContext3 != null && this.child.matches(lootContext3))) {
                return false;
            }
            return this.parent.matches(lootContext) && this.partner.matches(lootContext2) || this.parent.matches(lootContext2) && this.partner.matches(lootContext);
        }

        @Override
        public JsonObject serializeToJson(SerializationContext serializationContext) {
            JsonObject jsonObject = super.serializeToJson(serializationContext);
            jsonObject.add("parent", this.parent.toJson(serializationContext));
            jsonObject.add("partner", this.partner.toJson(serializationContext));
            jsonObject.add("child", this.child.toJson(serializationContext));
            return jsonObject;
        }
    }
}

